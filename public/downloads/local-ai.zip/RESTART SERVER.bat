@echo off
echo.
echo ========================================
echo   Restarting Chat Server
echo ========================================
echo.

REM Kill any existing chat server processes
echo Stopping existing chat server...
taskkill /f /fi "WINDOWTITLE eq Chat Server*" >nul 2>&1
timeout /t 1 /nobreak >nul

REM Start the chat server
echo Starting chat server...
start "Chat Server" node chat-server.js

echo.
echo Chat server restarted!
echo Check the "Chat Server" window for any errors.
echo.
echo Press any key to close this window...
pause >nul

