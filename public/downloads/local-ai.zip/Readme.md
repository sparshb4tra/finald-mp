# Local AI Chat Application

A fully local, privacy-focused AI chat interface powered by Ollama with modular model selection. All processing happens on your machine - no data leaves your computer.

## Features

- **100% Local**: All AI processing runs on your machine
- **Privacy First**: No data sent to external servers
- **Flexible Model Selection**: Choose any installed Ollama model from the UI
- **Chat History**: Persistent conversation storage in JSON format
- **Portable Conversations**: Existing chat context works across model switches
- **Cross-Platform**: Works on Windows, macOS, and Linux
- **Modern UI**: Clean, responsive web interface
- **Export Functionality**: Download your chat history anytime

## Requirements

- Node.js (v12 or higher)
- Ollama (will be installed automatically if missing)
- Modern web browser

## Quick Start

### Windows
Double-click `START CHAT (Windows).bat`

### macOS
**First-time setup (one-time only):**
```bash
chmod +x "START CHAT (Mac).command" && xattr -d com.apple.quarantine "START CHAT (Mac).command" 2>/dev/null || true
```
*(Note: If you see "No such xattr" error, it's harmless - the file wasn't quarantined)*

Then double-click `START CHAT (Mac).command` or run:
```bash
./"START CHAT (Mac).command"
```

### Linux
```bash
chmod +x "START CHAT (Linux).sh"
./"START CHAT (Linux).sh"
```

The launcher will:
1. Check for Ollama and install if needed
2. Ensure at least one local model exists (pulls a lightweight default if none are installed)
3. Start all required services
4. Open the chat interface in your browser

## Usage

Once launched, the chat interface opens at `http://localhost:8000/chat.html`

- Type your message and press Enter
- Pick the active model from the header model selector
- View chat history in the sidebar
- Create new chats with the "New Chat" button
- Export all chats using the "Export Chats" button

## Project Structure

```
├── chat.html              # Web interface
├── chat-server.js         # Backend server for chat storage
├── package.json           # Node.js dependencies
├── START CHAT (Windows).bat
├── START CHAT (Mac).command
├── START CHAT (Linux).sh
└── chats/                 # Chat history storage (JSON files)
```

## Technology Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js (chat server and web server)
- **AI Models**: Ollama (any installed local model)
- **Storage**: Local JSON files

## Model and Conversation Architecture

- Conversation data is model-agnostic (`messages` + metadata), so it remains reusable when switching models.
- Model execution is abstracted behind an adapter interface in the frontend:
  - `listModels()`
  - `health()`
  - `generateStream({ model, prompt })`
- The current backend is Ollama, but additional backends can be integrated with minimal changes by implementing the same adapter interface.

## Adding a New Backend Adapter

1. Add a new adapter object with `listModels`, `health`, and `generateStream`.
2. Register it in provider configuration.
3. Set it as active backend.
4. Keep conversation schema unchanged so chats stay portable across backends/models.

## Privacy

All data remains on your local machine. No internet connection required after initial setup (except for downloading the AI model).

## License

This project is submitted as a Minor Project.
