#!/bin/bash

# AI Chat Interface Launcher for Linux

set +e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

command_exists(){ command -v "$1" >/dev/null 2>&1; }
check_port(){
    if command_exists nc; then nc -z localhost "$1" >/dev/null 2>&1; return $?; fi
    curl -s -o /dev/null "http://localhost:$1" >/dev/null 2>&1; return $?
}

echo ""
echo "========================================"
echo "  AI Chat Interface Launcher"
echo "========================================"
echo ""

echo "[1/7] Working directory: $SCRIPT_DIR"
echo ""

echo "[2/7] Checking for Ollama installation..."
if ! command_exists ollama; then
    echo "    Ollama not found. Installing..."
    curl -fsSL https://ollama.com/install.sh | sh
    if ! command_exists ollama; then
        echo -e "${RED}ERROR: Ollama install failed.${NC}"
        exit 1
    fi
fi
echo "    Found Ollama"
echo ""

echo "[3/7] Checking prerequisites..."
if ! command_exists node; then
    echo "    Node.js not found. Installing..."
    if command_exists apt-get; then
        sudo apt-get update && sudo apt-get install -y nodejs npm
    elif command_exists yum; then
        sudo yum install -y nodejs npm
    elif command_exists dnf; then
        sudo dnf install -y nodejs npm
    elif command_exists pacman; then
        sudo pacman -S --noconfirm nodejs npm
    else
        echo -e "${RED}ERROR: Could not auto-install Node.js.${NC}"
        exit 1
    fi
fi
if ! command_exists node; then
    echo -e "${RED}ERROR: Node.js command failed.${NC}"
    exit 1
fi
echo "    - Ollama: Found (will start server later)"
echo "    - Node.js: OK"
echo "All prerequisites found"
echo ""

echo "[4/7] Configuring Ollama and starting server..."
export OLLAMA_ORIGINS="*"
if [ -f "$HOME/.bashrc" ] && ! grep -q "OLLAMA_ORIGINS" "$HOME/.bashrc"; then
    echo 'export OLLAMA_ORIGINS="*"' >> "$HOME/.bashrc"
fi
if [ -f "$HOME/.zshrc" ] && ! grep -q "OLLAMA_ORIGINS" "$HOME/.zshrc"; then
    echo 'export OLLAMA_ORIGINS="*"' >> "$HOME/.zshrc"
fi
echo "    - OLLAMA_ORIGINS set to * (current + profile where available)"

pkill -f "ollama serve" >/dev/null 2>&1 || true
sleep 2
nohup ollama serve >/dev/null 2>&1 &
OLLAMA_PID=$!

echo "    Waiting for Ollama server to start..."
WAIT_COUNT=0
while ! check_port 11434; do
    sleep 1
    WAIT_COUNT=$((WAIT_COUNT+1))
    if [ "$WAIT_COUNT" -ge 30 ]; then
        echo -e "${RED}ERROR: Ollama server failed to start after 30 seconds.${NC}"
        exit 1
    fi
done
echo "    Ollama server is running on port 11434"
echo ""

echo "[5/7] Checking available Ollama models..."
if ollama list >/dev/null 2>&1; then
    echo "    Current installed models:"
    ollama list
else
    echo "    WARNING: Could not query model list right now."
fi
DEFAULT_MODEL="llama3.2:3b"
echo "    Ensuring default model exists: ${DEFAULT_MODEL}"
ollama show "${DEFAULT_MODEL}" >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "    Default model missing. Skipping auto-pull to keep startup fast."
    echo "    Pull from app picker, or run: ollama pull ${DEFAULT_MODEL}"
else
    echo "    Default model already available."
fi
echo ""

echo "[6/7] Starting chat and web servers..."
if [ ! -f "chat-server.js" ]; then
    echo -e "${RED}ERROR: chat-server.js not found in $SCRIPT_DIR${NC}"
    exit 1
fi
if [ ! -d "node_modules" ]; then
    echo "Installing Node.js dependencies..."
    npm install
fi

nohup node chat-server.js >/dev/null 2>&1 &
CHAT_SERVER_PID=$!
echo "Waiting for chat server to start..."
for i in $(seq 1 15); do
    curl -s http://localhost:3000/api/health >/dev/null 2>&1 && break
    sleep 1
done
if curl -s http://localhost:3000/api/health >/dev/null 2>&1; then
    echo "Chat server is running on port 3000"
else
    echo "WARNING: Chat server may not be running properly!"
fi

nohup npm run web-server >/dev/null 2>&1 &
SERVER_PID=$!
sleep 3
if ! curl -s -I http://localhost:8000/chat.html >/dev/null 2>&1; then
    echo "WARNING: Web server may not be fully ready yet. Continuing anyway..."
fi

echo ""
echo "========================================"
echo "  AI Chat is ready"
echo "========================================"
echo ""
echo "  Chat Interface: http://localhost:8000/chat.html"
echo "  AI Model: configurable via in-app model picker"
echo "  Storage: Local JSON files in chats/ directory"
echo ""
echo "  Your browser should open automatically..."
echo "  To stop all services: Press Ctrl+C in this terminal"
echo ""

if command_exists xdg-open; then
    xdg-open "http://localhost:8000/chat.html" >/dev/null 2>&1
elif command_exists firefox; then
    firefox "http://localhost:8000/chat.html" >/dev/null 2>&1 &
elif command_exists google-chrome; then
    google-chrome "http://localhost:8000/chat.html" >/dev/null 2>&1 &
fi

cleanup(){
    echo ""
    echo "Stopping services..."
    kill "$CHAT_SERVER_PID" >/dev/null 2>&1 || true
    kill "$SERVER_PID" >/dev/null 2>&1 || true
    kill "$OLLAMA_PID" >/dev/null 2>&1 || true
    pkill -f "node chat-server.js" >/dev/null 2>&1 || true
    pkill -f "http-server" >/dev/null 2>&1 || true
    pkill -f "ollama serve" >/dev/null 2>&1 || true
    echo "All services stopped."
    exit 0
}
trap cleanup SIGINT SIGTERM
wait
