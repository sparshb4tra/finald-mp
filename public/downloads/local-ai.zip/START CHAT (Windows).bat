@echo off
REM AI Chat Interface Launcher for Windows
REM Double-click this file to start your AI assistant!

setlocal enabledelayedexpansion

echo.
echo ========================================
echo   AI Chat Interface Launcher
echo ========================================
echo.

REM Get the directory where this script is located
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

echo [1/7] Working directory: %SCRIPT_DIR%
echo.

REM Add Ollama to PATH using standard Windows locations
echo [2/7] Checking for Ollama installation...
set "OLLAMA_FOUND=0"

REM Check standard user installation location
set "OLLAMA_PATH=%LOCALAPPDATA%\Programs\Ollama"
if exist "%OLLAMA_PATH%\ollama.exe" (
    set "PATH=%PATH%;%OLLAMA_PATH%"
    set "OLLAMA_FOUND=1"
    echo    Found at: %OLLAMA_PATH%
)

REM Check Program Files location (if installed for all users)
if "%OLLAMA_FOUND%"=="0" (
    set "OLLAMA_PATH=%ProgramFiles%\Ollama"
    if exist "%OLLAMA_PATH%\ollama.exe" (
        set "PATH=%PATH%;%OLLAMA_PATH%"
        set "OLLAMA_FOUND=1"
        echo    Found at: %OLLAMA_PATH%
    )
)

REM Check if already in system PATH
if "%OLLAMA_FOUND%"=="0" (
    where ollama >nul 2>&1
    if not errorlevel 1 (
        set "OLLAMA_FOUND=1"
        echo    Found in system PATH
    )
)

echo.

REM Check prerequisites
echo [3/7] Checking prerequisites...
echo.

REM Check if Ollama is available
where ollama >nul 2>&1
if errorlevel 1 (
    if "%OLLAMA_FOUND%"=="0" (
        echo Ollama not found. Downloading installer...
        echo.
        
        REM Download Ollama installer
        set "OLLAMA_URL=https://ollama.com/download/OllamaSetup.exe"
        set "OLLAMA_INSTALLER=%TEMP%\OllamaSetup.exe"
        
        powershell -Command "Invoke-WebRequest -Uri ""%OLLAMA_URL%"" -OutFile ""%OLLAMA_INSTALLER%"""
        if errorlevel 1 (
            echo ERROR: Failed to download Ollama installer!
            echo.
            echo Opening browser to download page...
            start https://ollama.com/download
            echo.
            echo Please download and install Ollama, then run this script again.
            echo.
            pause
            exit /b 1
        )
        
        echo Ollama installer downloaded to: %OLLAMA_INSTALLER%
        echo.
        echo Please run the installer and then close this window and try again.
        echo.
        start "" "%OLLAMA_INSTALLER%"
        pause
        exit /b 1
    )
)

REM Verify Ollama is accessible (with timeout to prevent hanging)
if "%OLLAMA_FOUND%"=="1" (
    echo    - Ollama: Found ^(will start server later^)
) else (
    REM Try a quick version check with timeout
    echo    Testing Ollama...
    powershell -Command "$proc = Start-Process -FilePath 'ollama' -ArgumentList '--version' -NoNewWindow -PassThru -Wait -TimeoutSec 3; exit $proc.ExitCode" >nul 2>&1
    if not errorlevel 1 (
        echo    - Ollama: OK
    ) else (
        echo    - Ollama: Found ^(version check skipped, continuing...^)
    )
)

REM Check if Node.js is available
where node >nul 2>&1
if errorlevel 1 (
    echo Node.js not found. Downloading installer...
    echo.
    
    REM Download Node.js installer (LTS version)
    set "NODE_URL=https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi"
    set "NODE_INSTALLER=%TEMP%\nodejs-installer.msi"
    
    powershell -Command "Invoke-WebRequest -Uri ""%NODE_URL%"" -OutFile ""%NODE_INSTALLER%"""
    if errorlevel 1 (
        echo ERROR: Failed to download Node.js installer!
        echo.
        echo Opening browser to download page...
        start https://nodejs.org/
        echo.
        echo Please download and install Node.js, then run this script again.
        echo Make sure to check "Add to PATH" during installation!
        echo.
        pause
        exit /b 1
    )
    
    echo Node.js installer downloaded to: %NODE_INSTALLER%
    echo.
    echo Please run the installer and then close this window and try again.
    echo Make sure to check "Add to PATH" during installation!
    echo.
    start "" msiexec /i "%NODE_INSTALLER%"
    pause
    exit /b 1
)

node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js command failed!
    echo.
    echo Please ensure Node.js is properly installed.
    echo.
    pause
    exit /b 1
)

echo    - Node.js: OK

echo All prerequisites found
echo.

REM Configure CORS + start Ollama server in a consistent way
echo [4/7] Configuring Ollama and starting server...
set "OLLAMA_ORIGINS=*"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[System.Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS','*','User')" >nul 2>&1
echo    - OLLAMA_ORIGINS set to * (current + user profile)
taskkill /f /im ollama.exe >nul 2>&1
ping 127.0.0.1 -n 3 >nul

REM Start Ollama server
start "Ollama Server" /min ollama serve

REM Wait for Ollama server to start (max 30 seconds)
echo    Waiting for Ollama server to start...
set /a wait_count=0
:wait_ollama
ping 127.0.0.1 -n 2 >nul
netstat -an | findstr ":11434" >nul 2>&1
if not errorlevel 1 (
    echo    Ollama server is running on port 11434
    goto ollama_ready
)
set /a wait_count+=1
if %wait_count% geq 30 (
    echo ERROR: Ollama server failed to start after 30 seconds!
    echo.
    echo Please check if port 11434 is available or if Ollama is working.
    echo.
    pause
    exit /b 1
)
goto wait_ollama

:ollama_ready
echo.

REM Ensure at least one model is installed
echo [5/7] Checking available Ollama models...
ollama list >nul 2>&1
if errorlevel 1 (
    echo    WARNING: Could not query model list right now.
    echo    Continuing startup anyway...
) else (
    echo    Current installed models:
    ollama list
)

set "DEFAULT_MODEL=llama3.2:3b"
echo    Ensuring default model exists: %DEFAULT_MODEL%
ollama show %DEFAULT_MODEL% >nul 2>&1
if errorlevel 1 (
    echo    Default model missing. Skipping auto-pull to keep startup fast.
    echo    Pull from app picker, or run: ollama pull %DEFAULT_MODEL%
) else (
    echo    Default model already available.
)
echo.

:model_ready
echo.

REM Start chat server
echo [6/7] Starting chat and web servers...
cd /d "%SCRIPT_DIR%"
if not exist "chat-server.js" (
    echo ERROR: chat-server.js not found in %SCRIPT_DIR%
    echo.
    pause
    exit /b 1
)

REM Install Node.js dependencies if needed
if not exist "node_modules" (
    echo Installing Node.js dependencies...
    call npm install
    if errorlevel 1 (
        echo WARNING: npm install failed, continuing anyway...
    )
)

start "Chat Server" /min node chat-server.js
if errorlevel 1 (
    echo ERROR: Failed to start chat server!
    echo.
    pause
    exit /b 1
)

REM Wait a moment for chat server to start
echo Waiting for chat server to start...
ping 127.0.0.1 -n 4 >nul

REM Verify chat server is running
powershell -Command "try { $response = Invoke-WebRequest -Uri 'http://localhost:3000/api/health' -Method Get -UseBasicParsing -TimeoutSec 5; exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo WARNING: Chat server may not be running properly!
    echo Check the Chat Server window for errors.
    echo You can manually start it with: node chat-server.js
    echo.
) else (
    echo Chat server is running on port 3000
)

REM Start web server
start "Web Server" /min npm run web-server
if errorlevel 1 (
    echo ERROR: Failed to start web server!
    echo.
    pause
    exit /b 1
)

REM Wait a moment for web server to start
ping 127.0.0.1 -n 4 >nul

REM Verify web server is running
powershell -Command "try { $response = Invoke-WebRequest -Uri 'http://localhost:8000/chat.html' -Method Head -UseBasicParsing -TimeoutSec 5; exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo WARNING: Web server may not be fully ready yet. Continuing anyway...
    ping 127.0.0.1 -n 3 >nul
)

echo.
echo ========================================
echo   AI Chat is ready!
echo ========================================
echo.
echo   Chat Interface: http://localhost:8000/chat.html
echo   AI Model: configurable via in-app model picker
echo   Storage: Local JSON files in chats/ directory
echo.
echo   Your browser should open automatically...
echo.
echo   To stop all services: Press any key in this window
echo.

REM Open browser
ping 127.0.0.1 -n 3 >nul
start http://localhost:8000/chat.html

REM Wait for user input to stop
echo.
echo ========================================
echo   Press any key to stop all services...
echo ========================================
pause >nul

REM Cleanup - stop Ollama and servers
echo.
echo Stopping services...
taskkill /f /fi "WINDOWTITLE eq Chat Server*" >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq Web Server*" >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq Ollama Server*" >nul 2>&1
taskkill /f /im ollama.exe >nul 2>&1
taskkill /f /im node.exe >nul 2>&1
echo.
echo All services stopped.
echo.
pause

