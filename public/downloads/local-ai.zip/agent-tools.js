const fs = require('fs');
const fsPromises = fs.promises;
const path = require('path');
const https = require('https');
const { exec } = require('child_process');

const PROJECT_ROOT = path.resolve(__dirname);
const CHATS_DIR = path.join(PROJECT_ROOT, 'chats');
const SETTINGS_FILE = path.join(CHATS_DIR, 'agent_settings.json');
const OLLAMA_URL = 'http://localhost:11434/api/generate';

const DEFAULT_SYSTEM_PROMPT = [
  'You are a senior AI + systems assistant focused on clean, readable responses.',
  'For FINAL answers, use strict structure:',
  '1) Title (if applicable)',
  '2) Summary (1-3 lines)',
  '3) Main Content',
  '4) Optional: Steps / Breakdown / Notes',
  'Use markdown headings (##, ###), short paragraphs, bullets, and numbered steps.',
  'Avoid dense paragraphs, filler text, and UI-noise commentary.',
  'If technical/structured content appears (code/json/xml/commands/config), place it in fenced code blocks with correct language tags.',
  'Never mix explanation text inside code blocks. Keep code blocks copy-friendly and properly formatted.',
  'Auto-detect and prettify structured content with indentation and line breaks.',
  'Use tools when needed: bash for system tasks, file tools for files, web_search for unknown web info.',
  'Never hallucinate files/data/results. Verify with tools when possible before final answer.',
  'CRITICAL: Your assistant output to orchestrator must ALWAYS be strict JSON only.',
  'When choosing a tool call, respond only with:',
  '{"type":"tool","tool":"<name>","arguments":{...}}',
  'When giving the final user-facing response, respond only with:',
  '{"type":"final","content":"..."}'
].join('\n');

const TOOL_DEFINITIONS = [
  { name: 'web_search', description: 'Search web for up-to-date information', input: { query: 'string' } },
  { name: 'bash', description: 'Run shell commands with timeout/safety checks', input: { command: 'string', timeoutMs: 'number?' } },
  { name: 'read_file', description: 'Read a text file under project root', input: { path: 'string' } },
  { name: 'write_file', description: 'Overwrite file content under project root', input: { path: 'string', content: 'string' } },
  { name: 'create_file', description: 'Create new file (fails if exists) under project root', input: { path: 'string', content: 'string?' } },
  { name: 'update_file', description: 'Replace old text with new text in file under project root', input: { path: 'string', oldText: 'string', newText: 'string' } },
  { name: 'delete_file', description: 'Delete file under project root', input: { path: 'string' } },
  { name: 'list_directory', description: 'List directory contents under project root', input: { path: 'string?' } }
];

function ensureWithinProject(userPath) {
  const normalized = (userPath || '').replace(/\\/g, '/').replace(/^\/+/, '');
  const abs = path.resolve(PROJECT_ROOT, normalized);
  if (!(abs === PROJECT_ROOT || abs.startsWith(PROJECT_ROOT + path.sep))) {
    throw new Error('Path outside project root is not allowed');
  }
  return abs;
}

async function ensureSettingsFile() {
  await fsPromises.mkdir(CHATS_DIR, { recursive: true });
  try {
    await fsPromises.access(SETTINGS_FILE);
  } catch {
    const initial = { systemPrompt: DEFAULT_SYSTEM_PROMPT };
    await fsPromises.writeFile(SETTINGS_FILE, JSON.stringify(initial, null, 2), 'utf8');
  }
}

async function loadAgentSettings() {
  await ensureSettingsFile();
  try {
    const raw = await fsPromises.readFile(SETTINGS_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      systemPrompt: typeof parsed.systemPrompt === 'string' && parsed.systemPrompt.trim()
        ? parsed.systemPrompt
        : DEFAULT_SYSTEM_PROMPT
    };
  } catch {
    return { systemPrompt: DEFAULT_SYSTEM_PROMPT };
  }
}

async function saveAgentSettings(nextSettings) {
  await ensureSettingsFile();
  const payload = {
    systemPrompt: (nextSettings?.systemPrompt || DEFAULT_SYSTEM_PROMPT).toString()
  };
  await fsPromises.writeFile(SETTINGS_FILE, JSON.stringify(payload, null, 2), 'utf8');
  return payload;
}

function httpJSON(url, options = {}, bodyObj = null) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const isHttps = target.protocol === 'https:';
    const mod = isHttps ? require('https') : require('http');
    const body = bodyObj ? JSON.stringify(bodyObj) : null;
    const req = mod.request({
      hostname: target.hostname,
      port: target.port ? Number(target.port) : (isHttps ? 443 : 80),
      path: `${target.pathname}${target.search || ''}`,
      method: options.method || (body ? 'POST' : 'GET'),
      headers: {
        ...(options.headers || {}),
        ...(body ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } : {})
      }
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c.toString(); });
      res.on('end', () => {
        let parsed = null;
        try { parsed = raw ? JSON.parse(raw) : {}; } catch {}
        resolve({
          ok: res.statusCode >= 200 && res.statusCode < 300,
          status: res.statusCode,
          data: parsed,
          text: raw
        });
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function webSearchDuckDuckGo(query) {
  return new Promise((resolve, reject) => {
    const q = encodeURIComponent((query || '').trim());
    if (!q) return reject(new Error('query is required'));
    const url = `https://api.duckduckgo.com/?q=${q}&format=json&no_html=1&skip_disambig=1`;
    https.get(url, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk.toString(); });
      res.on('end', () => {
        try {
          const data = JSON.parse(body || '{}');
          const items = [];
          if (data.AbstractText) items.push({ title: data.Heading || 'Summary', snippet: data.AbstractText, url: data.AbstractURL || '' });
          const related = Array.isArray(data.RelatedTopics) ? data.RelatedTopics : [];
          for (const r of related) {
            if (items.length >= 5) break;
            if (r && r.Text) items.push({ title: 'Related', snippet: r.Text, url: r.FirstURL || '' });
          }
          resolve({ provider: 'duckduckgo', query, results: items.slice(0, 5) });
        } catch (e) {
          reject(new Error(`web_search parse failed: ${e.message}`));
        }
      });
    }).on('error', (e) => reject(new Error(`web_search failed: ${e.message}`)));
  });
}

async function webSearchExa(query, overrideKey = '') {
  const apiKey = String(overrideKey || process.env.EXA_API_KEY || '').trim();
  if (!apiKey) throw new Error('EXA_API_KEY not set');
  const payload = {
    query,
    numResults: 8,
    type: 'auto',
    useAutoprompt: true
  };

  // Exa has used multiple auth/header conventions; try both for robustness.
  let r = await httpJSON('https://api.exa.ai/search', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}` }
  }, payload);
  if (!r.ok) {
    r = await httpJSON('https://api.exa.ai/search', {
      method: 'POST',
      headers: { 'x-api-key': apiKey }
    }, payload);
  }

  if (!r.ok) throw new Error(`Exa error ${r.status}: ${r.text || 'request failed'}`);
  const list = Array.isArray(r.data?.results)
    ? r.data.results
    : Array.isArray(r.data?.data)
      ? r.data.data
      : [];
  if (!list.length) throw new Error('Exa returned no results');
  return {
    provider: 'exa',
    query,
    results: list.slice(0, 6).map((x) => {
      const text = x.text || x.snippet || x.summary || '';
      return {
        title: x.title || 'Result',
        snippet: text ? String(text).slice(0, 500) : '',
        url: x.url || ''
      };
    }).filter((x) => x.url || x.snippet || x.title)
  };
}

async function webSearchFirecrawl(query) {
  const apiKey = process.env.FIRECRAWL_API_KEY;
  if (!apiKey) throw new Error('FIRECRAWL_API_KEY not set');
  const r = await httpJSON('https://api.firecrawl.dev/v1/search', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}` }
  }, {
    query,
    limit: 5
  });
  if (!r.ok) throw new Error(`Firecrawl error ${r.status}: ${r.text || 'request failed'}`);
  const list = Array.isArray(r.data?.data) ? r.data.data : [];
  return {
    provider: 'firecrawl',
    query,
    results: list.slice(0, 5).map((x) => ({
      title: x.title || 'Result',
      snippet: x.description || x.markdown || '',
      url: x.url || ''
    }))
  };
}

async function webSearchGoogleNews(query) {
  const q = encodeURIComponent(String(query || '').trim());
  if (!q) throw new Error('query is required');
  const r = await httpJSON(`https://news.google.com/rss/search?q=${q}&hl=en-US&gl=US&ceid=US:en`);
  if (!r.ok) throw new Error(`Google News RSS error ${r.status}`);
  const xml = r.text || '';
  const itemMatches = xml.match(/<item>[\s\S]*?<\/item>/g) || [];
  const decode = (s) => String(s || '')
    .replace(/<!\[CDATA\[(.*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"');
  const results = itemMatches.slice(0, 6).map((item) => {
    const t = (item.match(/<title>([\s\S]*?)<\/title>/i) || [,''])[1];
    const l = (item.match(/<link>([\s\S]*?)<\/link>/i) || [,''])[1];
    const d = (item.match(/<description>([\s\S]*?)<\/description>/i) || [,''])[1];
    return {
      title: decode(t),
      snippet: decode(d).replace(/<[^>]+>/g, '').slice(0, 500),
      url: decode(l)
    };
  }).filter((x) => x.title || x.url);
  if (!results.length) throw new Error('Google News returned no results');
  return { provider: 'google-news-rss', query, results };
}

async function webSearch(query, preferredProvider = 'auto', opts = {}) {
  const q = String(query || '').trim();
  if (!q) throw new Error('query is required');
  const order = preferredProvider === 'exa'
    ? ['exa', 'firecrawl', 'google-news', 'duckduckgo']
    : preferredProvider === 'firecrawl'
      ? ['firecrawl', 'exa', 'google-news', 'duckduckgo']
      : ['exa', 'firecrawl', 'google-news', 'duckduckgo'];
  let lastErr = null;
  for (const p of order) {
    try {
      if (p === 'exa') return await webSearchExa(q, opts.exaApiKey);
      if (p === 'firecrawl') return await webSearchFirecrawl(q);
      if (p === 'google-news') return await webSearchGoogleNews(q);
      return await webSearchDuckDuckGo(q);
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('web search failed');
}

function isDangerousCommand(command) {
  const c = (command || '').toLowerCase();
  const blocked = [
    /rm\s+-rf\s+\/($|\s)/,
    /del\s+\/f\s+\/s\s+\/q\s+c:\\/i,
    /format\s+[a-z]:/i,
    /shutdown\s+/,
    /reboot\b/,
    /mkfs\./,
    /dd\s+if=.*of=\/dev\//,
    /diskpart/,
    /reg\s+delete\s+hkey/i
  ];
  return blocked.some((rx) => rx.test(c));
}

function runBash(command, timeoutMs = 12000) {
  return new Promise((resolve) => {
    if (!command || typeof command !== 'string') {
      resolve({ ok: false, error: 'command is required' });
      return;
    }
    if (isDangerousCommand(command)) {
      resolve({ ok: false, error: 'Blocked by safety filter' });
      return;
    }
    exec(command, {
      cwd: PROJECT_ROOT,
      timeout: Math.min(Math.max(Number(timeoutMs) || 12000, 500), 30000),
      maxBuffer: 1024 * 1024
    }, (error, stdout, stderr) => {
      resolve({
        ok: !error,
        exitCode: error && typeof error.code === 'number' ? error.code : 0,
        stdout: (stdout || '').toString(),
        stderr: (stderr || '').toString(),
        error: error ? error.message : null
      });
    });
  });
}

async function executeFileTool(tool, args) {
  const rel = args?.path || '';
  if (tool !== 'list_directory' && !rel) throw new Error('path is required');
  const abs = tool === 'list_directory' ? ensureWithinProject(rel || '.') : ensureWithinProject(rel);

  if (tool === 'read_file') {
    const content = await fsPromises.readFile(abs, 'utf8');
    return { path: path.relative(PROJECT_ROOT, abs), content };
  }
  if (tool === 'write_file') {
    await fsPromises.writeFile(abs, String(args?.content ?? ''), 'utf8');
    return { path: path.relative(PROJECT_ROOT, abs), written: true };
  }
  if (tool === 'create_file') {
    await fsPromises.writeFile(abs, String(args?.content ?? ''), { encoding: 'utf8', flag: 'wx' });
    return { path: path.relative(PROJECT_ROOT, abs), created: true };
  }
  if (tool === 'update_file') {
    const oldText = String(args?.oldText ?? '');
    const newText = String(args?.newText ?? '');
    const original = await fsPromises.readFile(abs, 'utf8');
    if (!oldText) throw new Error('oldText is required');
    if (!original.includes(oldText)) throw new Error('oldText not found');
    const updated = original.replace(oldText, newText);
    await fsPromises.writeFile(abs, updated, 'utf8');
    return { path: path.relative(PROJECT_ROOT, abs), updated: true };
  }
  if (tool === 'delete_file') {
    await fsPromises.unlink(abs);
    return { path: path.relative(PROJECT_ROOT, abs), deleted: true };
  }
  if (tool === 'list_directory') {
    const entries = await fsPromises.readdir(abs, { withFileTypes: true });
    return {
      path: path.relative(PROJECT_ROOT, abs) || '.',
      entries: entries.map((e) => ({ name: e.name, type: e.isDirectory() ? 'dir' : 'file' }))
    };
  }
  throw new Error(`Unknown file tool: ${tool}`);
}

function callOllama(model, prompt) {
  return new Promise((resolve, reject) => {
    const url = new URL(OLLAMA_URL);
    const payload = JSON.stringify({
      model,
      prompt,
      stream: false
    });
    const req = require('http').request({
      hostname: url.hostname,
      port: Number(url.port),
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c.toString(); });
      res.on('end', () => {
        if (res.statusCode >= 400) return reject(new Error(`Ollama HTTP ${res.statusCode}: ${body}`));
        try {
          const parsed = JSON.parse(body || '{}');
          resolve(String(parsed.response || '').trim());
        } catch (e) {
          reject(new Error(`Invalid Ollama response: ${e.message}`));
        }
      });
    });
    req.on('error', (e) => reject(e));
    req.write(payload);
    req.end();
  });
}

function extractJSON(text) {
  if (!text) return null;
  const direct = text.trim();
  try { return JSON.parse(direct); } catch {}
  const match = direct.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try { return JSON.parse(match[0]); } catch { return null; }
}

function extractToolDirectiveFromText(text) {
  const parsed = extractJSON(text);
  if (parsed && parsed.type === 'tool' && parsed.tool) return parsed;
  return null;
}

function toReadableSearchSummary(obj) {
  if (!obj || typeof obj !== 'object') return '';
  const results = Array.isArray(obj.results) ? obj.results : [];
  if (!results.length) return '';
  const lines = [];
  lines.push('Here are the latest results I found:');
  lines.push('');
  results.slice(0, 6).forEach((r, i) => {
    const title = String(r?.title || `Result ${i + 1}`).trim();
    const snippet = String(r?.snippet || '').replace(/\s+/g, ' ').trim();
    const url = String(r?.url || '').trim();
    lines.push(`${i + 1}. ${title}`);
    if (snippet) lines.push(`   - ${snippet.slice(0, 220)}${snippet.length > 220 ? '...' : ''}`);
    if (url) lines.push(`   - ${url}`);
  });
  return lines.join('\n');
}

function normalizeFinalAnswer(text) {
  const raw = String(text || '').trim();
  if (!raw) return '';

  // If model accidentally returns tool payload JSON, convert to readable summary.
  const parsed = extractJSON(raw);
  if (parsed && typeof parsed === 'object') {
    // Common case: raw web_search payload echoed to user
    if (Array.isArray(parsed.results)) {
      const pretty = toReadableSearchSummary(parsed);
      if (pretty) return pretty;
    }
    // Avoid leaking orchestration JSON to users
    if (parsed.type === 'tool' || parsed.tool || parsed.arguments) {
      return 'I executed the required tool workflow and can now share results in normal text. Please retry your request if this output still looks technical.';
    }
  }

  return raw;
}

async function executeToolCall(tool, args, opts = {}) {
  if (tool === 'web_search') {
    if (opts.webSearchEnabled === false) {
      return { ok: false, error: 'Web search is disabled by user toggle' };
    }
    return webSearch(String(args?.query || ''), opts.webSearchProvider || 'auto', { exaApiKey: opts.exaApiKey });
  }
  if (tool === 'bash') return runBash(String(args?.command || ''), Number(args?.timeoutMs || 12000));
  if (['read_file', 'write_file', 'create_file', 'update_file', 'delete_file', 'list_directory'].includes(tool)) {
    return executeFileTool(tool, args || {});
  }
  throw new Error(`Unknown tool: ${tool}`);
}

async function runAgent({ model, userMessage, systemPrompt, maxSteps = 6, webSearchEnabled = true, webSearchProvider = 'auto', exaApiKey = '' }) {
  if (!model) throw new Error('model is required');
  if (!userMessage) throw new Error('userMessage is required');

  const settings = await loadAgentSettings();
  const sp = (systemPrompt || settings.systemPrompt || DEFAULT_SYSTEM_PROMPT).trim();
  const toolContext = JSON.stringify({ tools: TOOL_DEFINITIONS }, null, 2);

  const transcript = [];
  const usedTools = [];
  const usedProviders = [];
  let currentInstruction = `User request:\n${userMessage}`;

  for (let step = 1; step <= maxSteps; step += 1) {
    const prompt = [
      sp,
      '',
      'Available tools:',
      toolContext,
      '',
      'Transcript so far:',
      transcript.map((t, i) => `${i + 1}. ${t}`).join('\n') || '(none)',
      '',
      currentInstruction,
      '',
      'Return JSON only.',
      'When returning final content, do NOT output raw tool payload JSON unless user explicitly asks for raw JSON.'
    ].join('\n');

    const raw = await callOllama(model, prompt);
    const decision = extractJSON(raw);
    if (!decision || !decision.type) {
      const toolDirective = extractToolDirectiveFromText(raw);
      if (toolDirective) {
        const toolName = String(toolDirective.tool || '');
        const args = toolDirective.arguments || {};
        let result;
        try {
          result = await executeToolCall(toolName, args, { webSearchEnabled, webSearchProvider, exaApiKey });
        } catch (e) {
          result = { ok: false, error: e.message };
        }
        usedTools.push(toolName);
        if (toolName === 'web_search' && result && typeof result === 'object' && result.provider) {
          usedProviders.push(String(result.provider));
        }
        transcript.push(`tool:${toolName} args=${JSON.stringify(args)}`);
        transcript.push(`result:${JSON.stringify(result)}`);
        currentInstruction = 'Use the latest tool result. If sufficient, return {"type":"final","content":"..."}';
        continue;
      }
      return {
        ok: true,
        answer: normalizeFinalAnswer(raw),
        steps: transcript,
        fallback: true,
        meta: { usedTools, usedProviders }
      };
    }

    if (decision.type === 'final') {
      const maybeTool = extractToolDirectiveFromText(String(decision.content || ''));
      if (maybeTool) {
        const toolName = String(maybeTool.tool || '');
        const args = maybeTool.arguments || {};
        let result;
        try {
          result = await executeToolCall(toolName, args, { webSearchEnabled, webSearchProvider, exaApiKey });
        } catch (e) {
          result = { ok: false, error: e.message };
        }
        usedTools.push(toolName);
        if (toolName === 'web_search' && result && typeof result === 'object' && result.provider) {
          usedProviders.push(String(result.provider));
        }
        transcript.push(`tool:${toolName} args=${JSON.stringify(args)}`);
        transcript.push(`result:${JSON.stringify(result)}`);
        currentInstruction = 'Use the latest tool result. If sufficient, return {"type":"final","content":"..."}';
        continue;
      }
      return {
        ok: true,
        answer: normalizeFinalAnswer(String(decision.content || '').trim()),
        steps: transcript,
        meta: { usedTools, usedProviders }
      };
    }

    if (decision.type === 'tool') {
      const toolName = String(decision.tool || '');
      const args = decision.arguments || {};
      let result;
      try {
        result = await executeToolCall(toolName, args, { webSearchEnabled, webSearchProvider, exaApiKey });
      } catch (e) {
        result = { ok: false, error: e.message };
      }
      usedTools.push(toolName);
      if (toolName === 'web_search' && result && typeof result === 'object' && result.provider) {
        usedProviders.push(String(result.provider));
      }
      transcript.push(`tool:${toolName} args=${JSON.stringify(args)}`);
      transcript.push(`result:${JSON.stringify(result)}`);
      currentInstruction = 'Use the latest tool result. If sufficient, return {"type":"final","content":"..."}';
      continue;
    }

    return { ok: true, answer: normalizeFinalAnswer(raw), steps: transcript, fallback: true, meta: { usedTools, usedProviders } };
  }

  return {
    ok: true,
    answer: 'Reached step limit before final answer. Please refine your request.',
    steps: transcript,
    limited: true,
    meta: { usedTools, usedProviders }
  };
}

module.exports = {
  TOOL_DEFINITIONS,
  DEFAULT_SYSTEM_PROMPT,
  loadAgentSettings,
  saveAgentSettings,
  runAgent
};

