# Local AI Chat Application

A fully local, privacy-focused AI chat interface powered by Ollama and Llama 3. All processing happens on your machine - no data leaves your computer.

## Features

- **100% Local**: All AI processing runs on your machine
- **Privacy First**: No data sent to external servers
- **Chat History**: Persistent conversation storage in JSON format
- **Cross-Platform**: Works on Windows, macOS, and Linux
- **Modern UI**: Clean, responsive web interface
- **Export Functionality**: Download your chat history anytime

## Requirements

- Node.js (v12 or higher)
- Ollama (will be installed automatically if missing)
- Modern web browser

## Quick Start

### Windows
Double-click `START CHAT (Windows).bat`

### macOS
**First-time setup (one-time only):**
```bash
chmod +x "START CHAT (Mac).command" && xattr -d com.apple.quarantine "START CHAT (Mac).command" 2>/dev/null || true
```
*(Note: If you see "No such xattr" error, it's harmless - the file wasn't quarantined)*

Then double-click `START CHAT (Mac).command` or run:
```bash
./"START CHAT (Mac).command"
```

### Linux
```bash
chmod +x "START CHAT (Linux).sh"
./"START CHAT (Linux).sh"
```

The launcher will:
1. Check for Ollama and install if needed
2. Download the AI model (dolphin-llama3) if not present
3. Start all required services
4. Open the chat interface in your browser

## Usage

Once launched, the chat interface opens at `http://localhost:8000/chat.html`

- Type your message and press Enter
- View chat history in the sidebar
- Create new chats with the "New Chat" button
- Export all chats using the "Export Chats" button

## Project Structure

```
├── chat.html              # Web interface
├── chat-server.js         # Backend server for chat storage
├── package.json           # Node.js dependencies
├── START CHAT (Windows).bat
├── START CHAT (Mac).command
├── START CHAT (Linux).sh
└── chats/                 # Chat history storage (JSON files)
```

## Technology Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js (chat server and web server)
- **AI Model**: Ollama with dolphin-llama3
- **Storage**: Local JSON files

## Privacy

All data remains on your local machine. No internet connection required after initial setup (except for downloading the AI model).

## License

This project is submitted as a Minor Project.
