#!/bin/bash

# AI Chat Interface Launcher for Linux
# Double-click this file to start your AI assistant!

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo -e "${BLUE}AI Chat Interface${NC}"
echo -e "${BLUE}================================${NC}"
echo ""

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check prerequisites
echo -e "${YELLOW}Checking prerequisites...${NC}"

# Check and install Ollama if missing
if ! command_exists ollama; then
    echo -e "${YELLOW}Ollama not found. Installing Ollama...${NC}"
    curl -fsSL https://ollama.com/install.sh | sh
    if [ $? -ne 0 ]; then
        echo -e "${RED}Failed to install Ollama.${NC}"
        echo -e "${YELLOW}Please install manually: curl -fsSL https://ollama.com/install.sh | sh${NC}"
        exit 1
    fi
    echo -e "${GREEN}Ollama installed successfully${NC}"
fi

# Check and install Node.js if missing
if ! command_exists node; then
    echo -e "${YELLOW}Node.js not found. Installing Node.js...${NC}"
    
    # Try different package managers
    if command_exists apt-get; then
        sudo apt-get update
        sudo apt-get install -y nodejs npm
    elif command_exists yum; then
        sudo yum install -y nodejs npm
    elif command_exists dnf; then
        sudo dnf install -y nodejs npm
    elif command_exists pacman; then
        sudo pacman -S --noconfirm nodejs npm
    else
        echo -e "${RED}Could not detect package manager.${NC}"
        echo -e "${YELLOW}Please install Node.js manually from: https://nodejs.org/${NC}"
        exit 1
    fi
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Failed to install Node.js.${NC}"
        echo -e "${YELLOW}Please install manually from: https://nodejs.org/${NC}"
        exit 1
    fi
    echo -e "${GREEN}Node.js installed successfully${NC}"
fi

echo -e "${GREEN}All prerequisites found${NC}"
echo ""

# Check if model exists
echo -e "${YELLOW}Checking dolphin-llama3 model...${NC}"
if ! ollama list | grep -q "dolphin-llama3"; then
    echo -e "${YELLOW}Downloading dolphin-llama3 model (this may take a while)...${NC}"
    ollama pull dolphin-llama3
fi
echo -e "${GREEN}Model ready${NC}"
echo ""

# Clean up any existing processes
echo -e "${YELLOW}Cleaning up existing processes...${NC}"
pkill -f "ollama serve" 2>/dev/null || true
pkill -f "http-server" 2>/dev/null || true
pkill -f "chat-server.js" 2>/dev/null || true
sleep 2

# Start Ollama server
echo -e "${YELLOW}Starting Ollama server...${NC}"
ollama serve &
OLLAMA_PID=$!

# Wait for Ollama server to start
echo "Waiting for Ollama server to start..."
while ! nc -z localhost 11434 2>/dev/null; do
    sleep 1
done
echo -e "${GREEN}Ollama server running on port 11434${NC}"

# Start chat server
echo -e "${YELLOW}Starting chat server...${NC}"
cd "$SCRIPT_DIR"

# Install Node.js dependencies if needed
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}Installing Node.js dependencies...${NC}"
    npm install
fi

node chat-server.js &
CHAT_SERVER_PID=$!

# Wait for chat server to start and verify it's running
echo "Waiting for chat server to start..."
sleep 3

# Verify chat server is running
if curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
    echo -e "${GREEN}Chat server running on port 3000${NC}"
else
    echo -e "${RED}WARNING: Chat server may not be running properly${NC}"
    echo -e "${YELLOW}Check the output above for errors${NC}"
    echo -e "${YELLOW}You can manually start it with: node chat-server.js${NC}"
fi

# Start web server
echo -e "${YELLOW}Starting web server...${NC}"
cd "$SCRIPT_DIR"
npm run web-server > /dev/null 2>&1 &
SERVER_PID=$!
sleep 2

# Verify web server is running
if curl -s -I http://localhost:8000/chat.html | grep -q "200 OK"; then
    echo -e "${GREEN}Web server running on port 8000${NC}"
else
    echo -e "${RED}ERROR: Failed to start web server${NC}"
    kill $OLLAMA_PID 2>/dev/null
    kill $CHAT_SERVER_PID 2>/dev/null
    exit 1
fi

echo ""
echo -e "${GREEN}AI Chat is ready!${NC}"
echo -e "${GREEN}================================${NC}"
echo -e "${BLUE}Chat Interface:${NC} http://localhost:8000/chat.html"
echo -e "${BLUE}AI Model:${NC} dolphin-llama3"
echo -e "${BLUE}Storage:${NC} Local JSON files in chats/ directory"
echo -e "${BLUE}Privacy:${NC} 100% local, no external data"
echo ""
echo -e "${YELLOW}Tip: Your browser should open automatically${NC}"
echo -e "${YELLOW}   Press Ctrl+C to stop all services${NC}"
echo ""

# Open browser
if command_exists xdg-open; then
    xdg-open "http://localhost:8000/chat.html"
elif command_exists firefox; then
    firefox "http://localhost:8000/chat.html" &
elif command_exists google-chrome; then
    google-chrome "http://localhost:8000/chat.html" &
fi

# Cleanup function
cleanup() {
    echo ""
    echo -e "${YELLOW}Stopping services...${NC}"
    kill $OLLAMA_PID 2>/dev/null || true
    kill $CHAT_SERVER_PID 2>/dev/null || true
    pkill -f "node chat-server.js" 2>/dev/null || true
    kill $SERVER_PID 2>/dev/null || true
    echo -e "${GREEN}Services stopped${NC}"
    exit 0
}

# Set trap to cleanup on script exit
trap cleanup SIGINT SIGTERM

# Keep the script running
wait

