#!/usr/bin/env node

/**
 * Dolphin AI Chat Server
 * A simple Node.js server for storing chat history in JSON files
 * Designed for portable USB drive usage
 */

const http = require('http');
const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const { URL } = require('url');

const PORT = 3000;
// Use local chats directory for portability across all platforms
const CHATS_DIR = path.join(__dirname, 'chats');

// Get index file path
function getIndexFile() {
    return path.join(CHATS_DIR, 'index.json');
}

// Ensure chats directory exists
async function ensureChatsDir() {
    try {
        // Create directory structure
        await fsPromises.mkdir(CHATS_DIR, { recursive: true });
        await fsPromises.mkdir(path.join(CHATS_DIR, 'backups'), { recursive: true });
        
        // Test write access
        const testFile = path.join(CHATS_DIR, '.write-test');
        try {
            await fsPromises.writeFile(testFile, 'test', 'utf8');
            await fsPromises.unlink(testFile);
        } catch (writeError) {
            throw new Error(`Directory exists but is not writable: ${writeError.message}`);
        }
        
        console.log('Chats directory ready:', CHATS_DIR);
    } catch (error) {
        throw new Error(`Cannot create chats directory: ${error.message}. Check permissions.`);
    }
}

// Rebuild index from existing chat_*.json files
async function rebuildIndex() {
    await ensureChatsDir();
    const files = await fsPromises.readdir(CHATS_DIR);
    const indexData = {};
    for (const f of files) {
        if (!f.endsWith('.json')) continue;
        if (f === 'index.json' || f === 'current_chat.json') continue;
            const full = path.join(CHATS_DIR, f);
        try {
            const data = JSON.parse(await fsPromises.readFile(full, 'utf8'));
            if (data && data.id) {
                indexData[data.id] = {
                    id: data.id,
                    title: data.title || 'New Chat',
                    createdAt: data.createdAt || new Date().toISOString(),
                    updatedAt: data.updatedAt || data.createdAt || new Date().toISOString(),
                    messageCount: Array.isArray(data.messages) ? data.messages.length : 0,
                    lastMessage: Array.isArray(data.messages) && data.messages.length > 0
                        ? String(data.messages[data.messages.length - 1].content || '').substring(0, 100) + '...'
                        : ''
                };
            }
        } catch {
            // Skip unreadable/corrupt individual chat files
        }
    }
    const indexFile = getIndexFile();
    const temp = indexFile + '.tmp';
    await fsPromises.writeFile(temp, JSON.stringify(indexData, null, 2), 'utf8');
    try { await fsPromises.unlink(indexFile); } catch {}
    await fsPromises.rename(temp, indexFile);
    return indexData;
}

// CORS headers
function setCORSHeaders(res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

// Send JSON response
function sendJSONResponse(res, data, statusCode = 200) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
    });
    res.end(JSON.stringify(data));
}

// Send error response
function sendError(res, statusCode, message) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
    });
    res.end(JSON.stringify({ error: message }));
}

// Get all chats
async function getAllChats(res) {
    try {
        try {
            const indexFile = getIndexFile();
            const data = await fsPromises.readFile(indexFile, 'utf8');
            const indexData = JSON.parse(data);
            // If index exists but is empty, try to rebuild once
            if (indexData && Object.keys(indexData).length === 0) {
                const rebuilt = await rebuildIndex();
                sendJSONResponse(res, rebuilt);
            } else {
                sendJSONResponse(res, indexData);
            }
        } catch (error) {
            if (error.code === 'ENOENT') {
                // Missing index -> rebuild
                const rebuilt = await rebuildIndex();
                sendJSONResponse(res, rebuilt);
            } else {
                // Parse error or other issue -> try rebuild once
                try {
                    const rebuilt = await rebuildIndex();
                    sendJSONResponse(res, rebuilt);
                } catch (rebuildErr) {
                    throw error;
                }
            }
        }
    } catch (error) {
        sendError(res, 500, `Error reading chats: ${error.message}`);
    }
}

// Get current chat
async function getCurrentChat(res) {
    try {
        const currentChatFile = path.join(CHATS_DIR, 'current_chat.json');
        try {
            const data = await fsPromises.readFile(currentChatFile, 'utf8');
            const chatData = JSON.parse(data);
            sendJSONResponse(res, chatData);
        } catch (error) {
            if (error.code === 'ENOENT') {
                sendJSONResponse(res, { currentChatId: null });
            } else {
                throw error;
            }
        }
    } catch (error) {
        sendError(res, 500, `Error reading current chat: ${error.message}`);
    }
}

// Get specific chat
async function getChat(res, chatId) {
    try {
        const chatFile = path.join(CHATS_DIR, `${chatId}.json`);
        try {
            const data = await fsPromises.readFile(chatFile, 'utf8');
            const chatData = JSON.parse(data);
            sendJSONResponse(res, chatData);
        } catch (error) {
            if (error.code === 'ENOENT') {
                sendError(res, 404, 'Chat not found');
            } else {
                throw error;
            }
        }
    } catch (error) {
        sendError(res, 500, `Error reading chat: ${error.message}`);
    }
}

// Validate chat data
function validateChatData(chatData) {
    const requiredFields = ['id', 'title', 'messages', 'createdAt', 'updatedAt'];
    
    for (const field of requiredFields) {
        if (!(field in chatData)) {
            return false;
        }
    }
    
    if (!Array.isArray(chatData.messages)) {
        return false;
    }
    
    for (const message of chatData.messages) {
        if (typeof message !== 'object' || message === null) {
            return false;
        }
        if (!message.role || !message.content || !message.timestamp) {
            return false;
        }
        if (!['user', 'assistant'].includes(message.role)) {
            return false;
        }
    }
    
    return true;
}

// Update chat index
async function updateChatIndex(chatData) {
    try {
        let indexData = {};
        const indexFile = getIndexFile();
        try {
            const data = await fsPromises.readFile(indexFile, 'utf8');
            indexData = JSON.parse(data);
        } catch (error) {
            // Index file doesn't exist, start with empty object
        }
        
        const chatId = chatData.id;
        indexData[chatId] = {
            id: chatId,
            title: chatData.title,
            createdAt: chatData.createdAt,
            updatedAt: chatData.updatedAt,
            messageCount: chatData.messages ? chatData.messages.length : 0,
            lastMessage: chatData.messages && chatData.messages.length > 0
                ? chatData.messages[chatData.messages.length - 1].content.substring(0, 100) + '...'
                : ''
        };
        
        const tempFile = indexFile + '.tmp';
        await fsPromises.writeFile(tempFile, JSON.stringify(indexData, null, 2), 'utf8');
        
        // Atomic move
        try {
            await fsPromises.unlink(indexFile);
        } catch (error) {
            // File might not exist, that's okay
        }
        await fsPromises.rename(tempFile, indexFile);
    } catch (error) {
        console.error('Warning: Could not update chat index:', error.message);
    }
}

// Save chat
async function saveChat(res, chatId, body) {
    try {
        const chatData = JSON.parse(body);
        
        if (!validateChatData(chatData)) {
            sendError(res, 400, 'Invalid chat data format');
            return;
        }
        
        await ensureChatsDir();
        
        const backupDir = path.join(CHATS_DIR, 'backups');
        const chatFile = path.join(CHATS_DIR, `${chatId}.json`);
        
        // Create backup if file exists
        let backupCreated = false;
        try {
            const stats = await fsPromises.stat(chatFile);
            if (stats.isFile()) {
                await fsPromises.mkdir(backupDir, { recursive: true });
                const backupFile = path.join(backupDir, `${chatId}_${Date.now()}.json`);
                await fsPromises.copyFile(chatFile, backupFile);
                backupCreated = true;
            }
        } catch (error) {
            // File doesn't exist, no backup needed
        }
        
        // Save new version
        const tempFile = chatFile + '.tmp';
        try {
            await fsPromises.writeFile(tempFile, JSON.stringify(chatData, null, 2), 'utf8');
        } catch (writeError) {
            console.error('Error writing temp file:', writeError);
            throw new Error(`Failed to write chat file: ${writeError.message}`);
        }
        
        // Atomic move
        try {
            try {
                await fsPromises.unlink(chatFile);
            } catch (error) {
                // File might not exist, that's okay
            }
            await fsPromises.rename(tempFile, chatFile);
        } catch (moveError) {
            console.error('Error moving temp file:', moveError);
            // Try to clean up temp file
            try {
                await fsPromises.unlink(tempFile);
            } catch (e) {
                // Ignore cleanup errors
            }
            throw new Error(`Failed to save chat file: ${moveError.message}`);
        }
        
        // Update index
        try {
            await updateChatIndex(chatData);
        } catch (indexError) {
            console.error('Error updating index:', indexError);
            // Don't fail the save if index update fails
        }
        
        sendJSONResponse(res, { success: true, backup_created: backupCreated });
    } catch (error) {
        console.error('Error in saveChat:', error);
        sendError(res, 500, `Error saving chat: ${error.message}`);
    }
}

// Save current chat
async function saveCurrentChat(res, body) {
    try {
        const data = JSON.parse(body);
        await ensureChatsDir();
        
        const currentChatFile = path.join(CHATS_DIR, 'current_chat.json');
        await fsPromises.writeFile(currentChatFile, JSON.stringify(data, null, 2), 'utf8');
        
        sendJSONResponse(res, { success: true });
    } catch (error) {
        sendError(res, 500, `Error saving current chat: ${error.message}`);
    }
}

// Delete chat
async function deleteChat(res, chatId) {
    try {
        await ensureChatsDir();
        
        const chatFile = path.join(CHATS_DIR, `${chatId}.json`);
        const backupDir = path.join(CHATS_DIR, 'backups');
        
        // Delete the chat file
        try {
            await fsPromises.unlink(chatFile);
            console.log(`Deleted chat file: ${chatFile}`);
        } catch (error) {
            if (error.code !== 'ENOENT') {
                throw error;
            }
            // File doesn't exist, that's okay
        }
        
        // Delete backups for this chat
        try {
            const backupFiles = await fsPromises.readdir(backupDir);
            for (const file of backupFiles) {
                if (file.startsWith(`${chatId}_`)) {
                    await fsPromises.unlink(path.join(backupDir, file));
                    console.log(`Deleted backup: ${file}`);
                }
            }
        } catch (error) {
            // Backup directory might not exist or be empty, that's okay
        }
        
        // Remove from index
        try {
            const indexFile = getIndexFile();
            const indexData = JSON.parse(await fsPromises.readFile(indexFile, 'utf8'));
            delete indexData[chatId];
            
            const tempFile = indexFile + '.tmp';
            await fsPromises.writeFile(tempFile, JSON.stringify(indexData, null, 2), 'utf8');
            try {
                await fsPromises.unlink(indexFile);
            } catch (error) {
                // File might not exist, that's okay
            }
            await fsPromises.rename(tempFile, indexFile);
        } catch (error) {
            console.error('Warning: Could not update index after deletion:', error.message);
            // Don't fail the deletion if index update fails
        }
        
        sendJSONResponse(res, { success: true, message: 'Chat deleted successfully' });
    } catch (error) {
        sendError(res, 500, `Error deleting chat: ${error.message}`);
    }
}

// Get health status
async function getHealthStatus(res) {
    try {
        let totalChats = 0;
        try {
            const files = await fsPromises.readdir(CHATS_DIR);
            totalChats = files.filter(f => f.endsWith('.json') && f !== 'index.json' && f !== 'current_chat.json').length;
        } catch (error) {
            // Directory might not exist
        }
        
        const stats = {
            status: 'healthy',
            timestamp: new Date().toISOString(),
            chats_directory: CHATS_DIR,
            total_chats: totalChats,
            disk_space_available: true,
            version: '1.0.0'
        };
        
        sendJSONResponse(res, stats);
    } catch (error) {
        sendError(res, 500, `Health check failed: ${error.message}`);
    }
}

// Export all chats
async function exportAllChats(res) {
    try {
        const exportData = {
            export_timestamp: new Date().toISOString(),
            version: '1.0.0',
            chats: {},
            index: {}
        };
        
        // Load index
        try {
            const indexFile = getIndexFile();
            const indexData = await fsPromises.readFile(indexFile, 'utf8');
            exportData.index = JSON.parse(indexData);
        } catch (error) {
            // Index doesn't exist
        }
        
        // Load all chats
        for (const chatId in exportData.index) {
            const chatFile = path.join(CHATS_DIR, `${chatId}.json`);
            try {
                const chatData = await fsPromises.readFile(chatFile, 'utf8');
                exportData.chats[chatId] = JSON.parse(chatData);
            } catch (error) {
                // Chat file doesn't exist, skip it
            }
        }
        
        const filename = `dolphin_chats_export_${Date.now()}.json`;
        res.writeHead(200, {
            'Content-Type': 'application/json',
            'Content-Disposition': `attachment; filename="${filename}"`,
            'Access-Control-Allow-Origin': '*'
        });
        res.end(JSON.stringify(exportData, null, 2));
    } catch (error) {
        sendError(res, 500, `Export failed: ${error.message}`);
    }
}

// Request handler
async function handleRequest(req, res) {
    try {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const pathname = url.pathname;
        const method = req.method;
        
        // Handle CORS preflight
        if (method === 'OPTIONS') {
            setCORSHeaders(res);
            res.writeHead(200);
            res.end();
            return;
        }
    
    // Handle GET requests
    if (method === 'GET') {
        if (pathname === '/api/chats') {
            await getAllChats(res);
        } else if (pathname === '/api/current-chat') {
            await getCurrentChat(res);
        } else if (pathname === '/api/rebuild-index') {
            try {
                const idx = await rebuildIndex();
                sendJSONResponse(res, { success: true, index: idx });
            } catch (e) {
                sendError(res, 500, `Rebuild failed: ${e.message}`);
            }
        } else if (pathname === '/api/health') {
            await getHealthStatus(res);
        } else if (pathname === '/api/export') {
            await exportAllChats(res);
        } else if (pathname.startsWith('/api/chats/')) {
            const chatId = pathname.split('/').pop();
            await getChat(res, chatId);
        } else {
            sendError(res, 404, 'Not Found');
        }
        return;
    }
    
    // Handle POST requests
    if (method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        
        req.on('end', async () => {
            if (pathname.startsWith('/api/chats/')) {
                const chatId = pathname.split('/').pop();
                await saveChat(res, chatId, body);
            } else if (pathname === '/api/current-chat') {
                await saveCurrentChat(res, body);
            } else {
                sendError(res, 404, 'Not Found');
            }
        });
        return;
    }
    
    // Handle DELETE requests
    if (method === 'DELETE') {
        if (pathname.startsWith('/api/chats/')) {
            const chatId = pathname.split('/').pop();
            console.log(`DELETE request for chat: ${chatId}`);
            await deleteChat(res, chatId);
        } else {
            console.log(`DELETE request for unknown path: ${pathname}`);
            sendError(res, 404, 'Not Found');
        }
        return;
    }
    
    // If we get here, method is not supported
    console.log(`Unsupported method: ${method} for path: ${pathname}`);
    sendError(res, 405, 'Method Not Allowed');
    } catch (error) {
        console.error('Error in handleRequest:', error);
        if (!res.headersSent) {
            sendError(res, 500, `Internal server error: ${error.message}`);
        }
    }
}

// Start server
async function startServer() {
    try {
        await ensureChatsDir();
    } catch (error) {
        console.error('Failed to initialize chats directory:', error);
        process.exit(1);
    }
    
    const server = http.createServer((req, res) => {
        handleRequest(req, res).catch(error => {
            console.error('Unhandled request error:', error);
            if (!res.headersSent) {
                sendError(res, 500, `Internal server error: ${error.message}`);
            }
        });
    });
    
    server.listen(PORT, 'localhost', () => {
        console.log(`Chat server running on http://localhost:${PORT}`);
        console.log(`Chats stored in: ${CHATS_DIR}`);
    });
    
    server.on('error', (error) => {
        console.error('Error starting chat server:', error.message);
        if (error.code === 'EADDRINUSE') {
            console.error(`Port ${PORT} is already in use. Please stop the existing server.`);
        }
        process.exit(1);
    });
    
    // Handle graceful shutdown
    process.on('SIGINT', () => {
        console.log('\nStopping chat server...');
        server.close(() => {
            console.log('Chat server stopped');
            process.exit(0);
        });
    });
    
    process.on('uncaughtException', (error) => {
        console.error('Uncaught exception:', error);
    });
    
    process.on('unhandledRejection', (error) => {
        console.error('Unhandled rejection:', error);
    });
}

// Main
console.log('Dolphin AI Chat Server');
console.log('========================');
console.log(`Starting on port ${PORT}...`);
console.log(`Chats directory: ${CHATS_DIR}`);
console.log('');

startServer().catch(error => {
    console.error('Failed to start chat server:', error);
    console.error('Error details:', error.stack);
    console.error('');
    console.error('Troubleshooting:');
    console.error('1. Check if port 3000 is already in use');
    console.error('2. Verify Node.js is installed: node --version');
    console.error('3. Check file permissions for the project directory');
    console.error('4. Try running: npm install');
    process.exit(1);
});

